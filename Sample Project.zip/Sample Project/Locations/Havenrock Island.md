---
type: world
name: "Havenrock Island"
region: "Cornwall, England"
climate: "Atlantic maritime — mild winters, cool summers, frequent fog and storms"
population: "Around 400 permanent residents"
description: "A small, rugged island off the Cornish coast, accessible only by ferry or private boat. Rocky cliffs, hidden coves, a single harbor, and a 19th-century lighthouse define the landscape. Once a thriving fishing community, it's now caught between preservation and a controversial resort development."
history: "Settled since the Bronze Age. The Blackwood family has owned most of the land since the 1800s. The island's darkest secret — the murder of Thomas Hartwell in 1982 — has shaped its politics for over forty years."
tags:
  - island
  - cornwall
  - coastal
  - mystery
---

# Havenrock Island

A windswept island off the coast of Cornwall. Home to about 400 souls, a crumbling lighthouse, and a secret that has festered for over forty years.

The island is divided between old fishing families and newcomers attracted by the Blackwood resort plans. A single ferry connects it to the mainland, running twice daily in summer and once in winter — weather permitting.

## Key Locations
- [[The Harbor]] — Heart of the village
- [[Grandmother's Cottage]] — Eleanor Hartwell's home
- [[The Lighthouse]] — Abandoned, holds crucial evidence
- [[The Anchor Tavern]] — Where everyone talks and no one tells the truth
- [[Blackwood Manor]] — The seat of island power
