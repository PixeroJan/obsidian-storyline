---
type: location
name: Blackwood Manor
created: 2026-02-22
modified: 2026-02-22
world: Havenrock Island
---
