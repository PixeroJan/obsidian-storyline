---
type: location
name: The Anchor Tavern
created: 2026-02-22
modified: 2026-02-22
world: Havenrock Island
---
