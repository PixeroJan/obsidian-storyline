---
type: location
name: Grandmother's Cottage
created: 2026-02-22
modified: 2026-02-22
world: Havenrock Island
---
