---
type: location
name: The Harbor
world: Havenrock Island
locationType: landmark
atmosphere: Salt air, creaking boats, gulls overhead. Smells of diesel and fish. The stone quay is slick with spray. Lobster pots stacked three high along the wall.
significance: The only way on and off the island. Thomas Hartwell departed from here the night he was killed. The harbor records — kept in the harbormaster's shed — contain discrepancies that Jack Mercer has been quietly tracking.
inhabitants:
  - Jack Mercer
  - Various fishermen
tags:
  - harbor
  - public
  - clues
modified: 2026-02-22
world: Havenrock Island
---

# The Harbor

The beating heart of [[Havenrock Island]]. Every arrival and departure passes through its stone quay. [[Jack Mercer]] moors his boat *The Skylark* here and knows every tide, every current, and every face that steps off the ferry.

The harbormaster's shed holds logbooks going back decades. The entry for August 14, 1982 — the night [[Thomas Hartwell]] disappeared — shows a boat departure that was never explained.