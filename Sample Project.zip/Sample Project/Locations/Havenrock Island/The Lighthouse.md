---
type: location
name: The Lighthouse
world: Havenrock Island
locationType: landmark
atmosphere: Abandoned for years. Iron door hangs open. Salt-crusted glass in the lamp room. The spiral staircase groans underfoot. Below, sea caves echo with the tide. At night, the wind sounds like voices.
significance: The most important location in the mystery. Thomas Hartwell's body was hidden in the sea caves beneath the lighthouse. Eleanor painted it obsessively as a form of confession. The climax of the story takes place here.
inhabitants: []
tags:
  - lighthouse
  - abandoned
  - climax
  - evidence
modified: 2026-02-22
world: Havenrock Island
---

# The Lighthouse

Perched on the northern cliffs of [[Havenrock Island]], the lighthouse has been decommissioned since the 1990s. Officially, it's unsafe. Unofficially, [[Howard Blackwood]] has made sure no one goes near it.

Below the lighthouse, sea caves twist into the rock. This is where Algernon Blackwood hid [[Thomas Hartwell]]'s body in August 1982. The caves are only accessible at low tide — a detail [[Eleanor Hartwell]] encoded in her paintings.

In the lamp room, someone has scratched initials into the glass: **T.H. + E.H. — 1965**