---
type: location
name: Grandmother's Cottage
world: Havenrock Island
locationType: building
atmosphere: Stone walls, low ceilings, the smell of oil paint and dried lavender. Every surface holds a memory — framed photographs, seashells, half-finished canvases. The attic studio is untouched, brushes still in their jars.
significance: Eleanor Hartwell's home for over fifty years, now inherited by Emma. The letter is found here, hidden inside a paint box. The attic studio contains the lighthouse paintings that encode Eleanor's clues.
inhabitants:
  - Emma Hartwell (current)
  - Eleanor Hartwell (deceased)
tags:
  - cottage
  - private
  - clues
  - art
modified: 2026-02-22
world: Havenrock Island
---

# Grandmother's Cottage

A stone cottage on the cliff path above [[The Harbor]]. Home to [[Eleanor Hartwell]] for over fifty years, it now belongs to [[Emma Hartwell]]. The cottage is a character in itself — every room holds layers of memory.

The **attic studio** is where Eleanor painted obsessively. Her lighthouse paintings, hanging on every wall, contain hidden details — map coordinates, dates, and a figure in the water that no one noticed until now.

[[Eleanor's Letter]] was found here, tucked inside the #PaintBox.