---
type: location
name: The Anchor Tavern
world: Havenrock Island
locationType: building
atmosphere: Low beams, a roaring fireplace, the clink of pint glasses. Photographs of island history cover the walls. The dartboard has seen better days. Everyone knows everyone, and conversations drop to whispers when strangers walk in.
significance: The island's social hub. Key scenes of confrontation and revelation happen here. Howard Blackwood holds court in the snug. Maggie Shaw sits by the fire every Thursday evening. The publican, Old Bill, hears everything.
inhabitants:
  - Old Bill (publican)
  - Island regulars
tags:
  - tavern
  - public
  - social
  - confrontation
modified: 2026-02-22
world: Havenrock Island
---

# The Anchor Tavern

The only pub on [[Havenrock Island]] — and therefore the center of all gossip, alliances, and barely concealed feuds. Stone floors, a fire that never goes out, and a menu of exactly four dishes.

[[Howard Blackwood]] has a reserved table in the snug. [[Maggie Shaw]] drinks sherry by the fire every Thursday. When [[Emma Hartwell]] walks in for the first time, the room goes quiet for exactly three seconds.

Old Bill, the publican, claims to remember nothing about 1982. His eyes say otherwise.