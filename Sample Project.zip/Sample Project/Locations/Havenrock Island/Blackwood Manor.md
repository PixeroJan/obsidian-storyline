---
type: location
name: Blackwood Manor
world: Havenrock Island
locationType: building
atmosphere: "Grand but oppressive. Ivy-covered stone, tall windows overlooking the sea, immaculate gardens maintained by hired staff. Inside: dark wood paneling, oil paintings of Blackwood ancestors, a study that smells of leather and Scotch. Everything designed to intimidate."
significance: Seat of the Blackwood family's power. Algernon's journal — detailing the murder and land fraud — is hidden in the study safe. Emma and Jack break in during Act 2 to find it.
inhabitants:
  - Howard Blackwood
  - Diane Blackwood
tags:
  - manor
  - private
  - evidence
  - power
modified: 2026-02-22
world: Havenrock Island
---

# Blackwood Manor

The largest property on [[Havenrock Island]], sitting on a hill above the village. Home to the Blackwood family for three generations. [[Howard Blackwood]] inherited it from his grandfather Algernon, along with the family's secrets and sins.

The **study safe** contains Algernon's journal — a meticulous record of the land fraud and, buried in the final pages, a coded confession to [[Thomas Hartwell]]'s murder. Howard has never opened the journal. He doesn't need to. He already knows what it says.

The **gardens** are where Howard meets contacts about the resort development. The **wine cellar** connects to an old smuggler's passage that leads to the cliff path — useful for people who don't want to be seen leaving.