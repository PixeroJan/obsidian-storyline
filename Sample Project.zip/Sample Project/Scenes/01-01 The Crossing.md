---
type: scene
title: The Crossing
act: 1
chapter: 1
sequence: 1
status: written
pov: Emma Hartwell
location: The Harbor
characters:
  - Emma Hartwell
  - Jack Mercer
intensity: 3
tags:
  - mystery
  - homecoming
  - arrival
wordTarget: 2500
notes: Opening scene. Establish mood, island setting, Emma's emotional state. First glimpse of Jack at the harbor.
setup_scenes: []
payoff_scenes:
  - 01-02 The Letter
  - 02-06 Jack's Secret
  - The Letter
  - Jack's Secret
modified: 2026-02-22
wordcount: 209
---

The ferry rounded the headland and [[Havenrock Island]] appeared through the mist — a dark ridge of rock and gorse, crowned by the silhouette of [[The Lighthouse]].

Emma Hartwell hadn't been back in fifteen years. Not since the summer she turned seventeen, when her grandmother [[Eleanor Hartwell|Eleanor]] had pressed a paintbrush into her hand and said, *"This island will always be here for you."*

Now Eleanor was dead, and here Emma was — not for the island, but for the cottage, the will, and whatever else needed sorting before she could get back to London.

The ferry bumped against the quay at [[The Harbor]]. A handful of passengers shuffled off. Emma slung her bag over her shoulder and stepped onto wet stone.

A man was coiling rope on the dock. Dark curly hair, cable-knit sweater, hands that looked like they'd never seen an office. He glanced up as she passed.

"Hartwell?" he said.

She stopped. "Do I know you?"

"No." He went back to his rope. "But I knew your grandmother."

She watched him for a moment, then walked on. The wind carried the smell of salt and diesel, and underneath it something else — something she couldn't name but recognized immediately.

The feeling of coming home to a place that didn't want her back.