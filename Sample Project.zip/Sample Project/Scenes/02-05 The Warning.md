---
type: scene
title: "The Warning"
act: 2
chapter: 5
sequence: 5
status: draft
pov: "Emma Hartwell"
location: "The Anchor Tavern"
characters:
  - Emma Hartwell
  - Howard Blackwood
intensity: 7
tags:
  - confrontation
  - threat
  - politics
  - suspense
wordTarget: 1800
notes: "Howard approaches Emma at the pub. Veiled threats disguised as friendly advice. First direct antagonist confrontation."
setup_scenes:
  - "01-04 The Painting"
payoff_scenes:
  - "02-08 Breaking In"
  - "03-10 The Confrontation"
---

[[Howard Blackwood]] found her at [[The Anchor Tavern]]. Of course he did — someone had told him she'd been asking questions, and on an island this small, news traveled faster than the tide.

He slid into the seat opposite with the ease of a man who owned every chair in the room. Silver hair, tailored jacket, a gold signet ring that he turned slowly on his finger.

"Miss Hartwell," he said, with a smile that didn't quite reach his eyes. "I wanted to offer my condolences. Your grandmother was a remarkable woman. The island won't be the same without her."

"Thank you," Emma said carefully.

"I also wanted to offer some friendly advice." He leaned forward. "Eleanor was — well, she was a painter. Wonderful imagination. But toward the end, she became a bit confused. Said things that... didn't always reflect reality. I'd hate for anyone to take her ramblings seriously."

"What kind of ramblings?"

Howard's smile thinned. "The kind that could hurt people. Reputations. Families that have served this island for generations." He paused. "Your family included."

The threat was wrapped in silk, but it was a threat nonetheless.

"I'm a journalist, Mr. Blackwood. People threaten me before breakfast."

"I'm not threatening you," he said, adjusting his signet ring. "I'm just reminding you that Havenrock is a small community. We take care of our own. And we don't appreciate outsiders stirring up old ghosts."

He stood, buttoned his jacket, and dropped a twenty-pound note on the table. "For your drink," he said. "Welcome home."
