---
type: scene
title: "Breaking In"
act: 2
chapter: 8
sequence: 8
status: idea
pov: "Emma Hartwell"
location: "Blackwood Manor"
characters:
  - Emma Hartwell
  - Jack Mercer
  - Howard Blackwood
intensity: 9
tags:
  - suspense
  - danger
  - evidence
  - trespassing
wordTarget: 2500
notes: "Emma and Jack break into Blackwood Manor through the smuggler's passage while Howard is at a council meeting. They find Algernon's journal in the study safe. It confirms everything — the land fraud, the murder, the cover-up. They photograph the pages but are nearly caught when Howard returns early."
setup_scenes:
  - "02-06 Jack's Secret"
  - "02-07 The Storm"
payoff_scenes:
  - "03-10 The Confrontation"
---
