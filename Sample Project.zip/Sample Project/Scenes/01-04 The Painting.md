---
type: scene
title: "The Painting"
act: 1
chapter: 4
sequence: 4
status: draft
pov: "Emma Hartwell"
location: "Grandmother's Cottage"
characters:
  - Emma Hartwell
  - Jack Mercer
intensity: 6
tags:
  - discovery
  - clues
  - art
  - trust
wordTarget: 2000
notes: "Emma decodes one of Eleanor's paintings and finds coordinates. Jack arrives unannounced with his father's logbook. Alliance begins to form."
setup_scenes:
  - "01-02 The Letter"
  - "01-03 What Maggie Knows"
payoff_scenes:
  - "02-05 The Warning"
  - "02-08 Breaking In"
---

Emma spent the morning photographing every painting in the attic studio. Thirty-seven canvases, all of [[The Lighthouse]], all in Eleanor's distinctive style — vivid blues and greys, dramatic skies, the white tower stark against the rock.

But now she was looking properly, she could see what she'd missed before.

In the bottom corner of each painting, hidden in the brushstrokes of the sea, there were numbers. Coordinates. Dates. And in one painting — the largest, hung above the fireplace downstairs — a figure in the water. Not drowning. Reaching up.

She was staring at it when someone knocked on the door.

[[Jack Mercer]] stood on the threshold, a battered leather notebook in his hand. He looked uncomfortable — like a man who'd been arguing with himself all morning and lost.

"I heard you were asking about 1982," he said. "My father kept a logbook. There's an entry you should see."

He held out the #FathersLogbook. Emma took it.

The entry for August 14, 1982 read: *Boat out past midnight. Not Thomas's usual schedule. Blackwood's man at the quay. Something wrong. Ask tomorrow.*

There was no entry for August 15th. Or any day after that.

"Your father never asked," Emma said.

"He died before he could." Jack's jaw tightened. "Heart attack, six months later. I've always wondered if it was really his heart that killed him."

They stood in the doorway — journalist and fisherman, both holding pieces of the same puzzle.

"I think we should talk," Emma said.

"I think we should," Jack agreed.
