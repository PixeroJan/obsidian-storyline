---
type: scene
title: "The Aftermath"
act: 3
chapter: 9
sequence: 12
status: idea
pov: "Emma Hartwell"
location: "The Lighthouse"
characters:
  - Emma Hartwell
  - Jack Mercer
intensity: 4
tags:
  - resolution
  - romance
  - closure
  - hope
wordTarget: 1500
notes: "Final scene. Dawn at the lighthouse. Emma and Jack look out at the sea. Emma has written Thomas's story — not as an exposé, but as a tribute. She's decided to stay on Havenrock. Jack gives her Thomas's wedding ring, recovered from the sea caves. She puts it on her grandmother's chain. The lighthouse light, repaired by the village, comes on for the first time in thirty years."
setup_scenes:
  - "03-10 The Confrontation"
  - "03-11 Maggie's Confession"
payoff_scenes: []
---
