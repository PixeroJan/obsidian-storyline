---
type: scene
title: The Letter
act: 1
chapter: 2
sequence: 2
status: written
pov: Emma Hartwell
location: Grandmother's Cottage
characters:
  - Emma Hartwell
  - Eleanor Hartwell
intensity: 7
tags:
  - mystery
  - family-secrets
  - discovery
  - clues
wordTarget: 2000
notes: Key inciting incident. Emma finds Eleanor's letter hidden in the paint box. The central mystery is launched.
setup_scenes:
  - 01-01 The Crossing
  - The Crossing
payoff_scenes:
  - 01-03 What Maggie Knows
  - 01-04 The Painting
modified: 2026-02-22
wordcount: 312
---

[[Grandmother's Cottage]] smelled exactly as Emma remembered — oil paint, dried lavender, and the faint sweetness of wood smoke. The low ceilings pressed down like a held breath.

She set her bag in the hallway and stood for a moment, listening. The tick of the mantel clock. The creak of old timber. The silence where [[Eleanor Hartwell|Eleanor]]'s voice should have been.

The solicitor had said to look through the studio. *"Your grandmother left instructions. Said you'd understand."*

The attic studio was exactly as Eleanor had left it. Brushes in jars of clouded turpentine. Canvases stacked against the walls — all of them [[The Lighthouse]], painted from every angle, in every light. Dozens of them. Maybe a hundred.

Emma picked up the #PaintBox from the easel shelf. Heavy. She opened it.

Beneath the tubes of cadmium and cobalt, she found an envelope. Cream paper, sealed with wax. Her name in Eleanor's careful hand.

She broke the seal.

*My dearest Emma,*

*If you're reading this, then I've run out of time. I should have told you years ago, but I was afraid — afraid of what it would cost, afraid of what they would do. I'm not afraid anymore.*

*Your grandfather Thomas didn't drown. He was murdered. Algernon Blackwood killed him on the night of August 14, 1982, because Thomas discovered the land fraud — the forged deeds that gave the Blackwoods half the island.*

*I have proof. It's in the paintings. Look at the lighthouse. Look carefully.*

*I'm sorry I couldn't say this while I was alive. The Blackwoods made sure of that. But you're braver than I ever was, Emma. You always were.*

*Find the truth. Tell his story.*

*All my love,*
*Eleanor*

Emma read it twice. Then she sat on the studio floor, the letter in her lap, and stared at the lighthouse paintings lining the walls. 

Every single one of them was a confession.