---
type: scene
title: Jack's Secret
act: 2
chapter: 6
sequence: 6
status: outlined
pov: Jack Mercer
location: The Lighthouse
characters:
  - Jack Mercer
  - Emma Hartwell
intensity: 6
tags:
  - trust
  - romance
  - backstory
  - vulnerability
wordTarget: 2000
notes: Jack takes Emma to the lighthouse at dawn. Reveals what he's been piecing together for years — harbor records don't add up. They find the scratched initials T.H. + E.H. Emotional turning point in their relationship.
setup_scenes:
  - 01-04 The Painting
  - 02-05 The Warning
  - The Crossing
payoff_scenes:
  - 02-07 The Storm
  - 03-10 The Confrontation
modified: 2026-02-22
wordcount: 138
---

Jack takes Emma to [[The Lighthouse]] at dawn. Shows her the harbor logbook discrepancies he's been tracking — boats that left but never returned, entries crossed out, a whole page torn from the night of August 14, 1982.

In the lamp room, they find the scratched initials: **T.H. + E.H. — 1965**. Emma traces them with her finger.

Jack reveals his father's suspicion — and his guilt for never following up. Emma tells Jack about the coordinates hidden in Eleanor's paintings. They realize the paintings point to the sea caves beneath the lighthouse.

The tide is too high to explore. They sit on the cliff edge and watch the sunrise. Something shifts between them — trust replacing caution.

*"Why are you helping me?" Emma asks.*

*"Because my father would have wanted me to. And because some things shouldn't stay buried."*