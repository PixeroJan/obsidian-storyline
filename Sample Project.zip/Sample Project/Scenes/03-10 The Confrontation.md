---
type: scene
title: "The Confrontation"
act: 3
chapter: 9
sequence: 10
status: idea
pov: "Emma Hartwell"
location: "The Lighthouse"
characters:
  - Emma Hartwell
  - Jack Mercer
  - Howard Blackwood
intensity: 10
tags:
  - climax
  - confrontation
  - justice
  - danger
wordTarget: 3000
notes: "The climax. Emma confronts Howard at the lighthouse with all the evidence — the letter, the paintings, the logbook, Algernon's journal. Howard's façade cracks. He didn't commit the murder, but he's spent his life covering it up. Jack is there as backup. The police boat is already on its way."
setup_scenes:
  - "02-05 The Warning"
  - "02-06 Jack's Secret"
  - "02-08 Breaking In"
payoff_scenes:
  - "03-11 Maggie's Confession"
  - "03-12 The Aftermath"
---
