---
type: scene
title: "The Storm"
act: 2
chapter: 7
sequence: 7
status: idea
pov: "Emma Hartwell"
location: "Grandmother's Cottage"
characters:
  - Emma Hartwell
  - Jack Mercer
intensity: 8
tags:
  - suspense
  - danger
  - escalation
wordTarget: 2500
notes: "A violent storm hits the island. During the night, someone breaks into the cottage and searches the attic studio. Several paintings are slashed. The letter is safe — Emma carries it on her person. Jack arrives to check on her. They realize Blackwood is getting desperate."
setup_scenes:
  - "02-05 The Warning"
  - "02-06 Jack's Secret"
payoff_scenes:
  - "02-08 Breaking In"
  - "03-10 The Confrontation"
---
