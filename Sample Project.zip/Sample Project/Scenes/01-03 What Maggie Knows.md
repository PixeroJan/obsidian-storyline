---
type: scene
title: "What Maggie Knows"
act: 1
chapter: 3
sequence: 3
status: draft
pov: "Emma Hartwell"
location: "The Anchor Tavern"
characters:
  - Emma Hartwell
  - Maggie Shaw
intensity: 5
tags:
  - mystery
  - clues
  - trust
wordTarget: 1800
notes: "First meeting with Maggie. She's warm but evasive. Drops hints that something isn't right about the official story. Emma senses she knows more."
setup_scenes:
  - "01-02 The Letter"
payoff_scenes:
  - "03-11 Maggie's Confession"
---

Emma found [[Maggie Shaw]] exactly where the postmistress said she'd be — at [[The Anchor Tavern]], by the fire, nursing a glass of sherry and reading a Daphne du Maurier novel.

"Mrs. Shaw?"

The old woman looked up. Her eyes were sharp behind her reading glasses, and for a moment something crossed her face — recognition, then something more complicated. Fear, maybe. Or relief.

"You look just like her," Maggie said quietly. "Sit down, dear. I've been expecting you."

Emma sat. Maggie ordered tea without asking.

"You know why I'm here," Emma said.

"I know why your grandmother wanted you here. That's not quite the same thing." Maggie stirred her tea precisely three times, then set down the spoon. "Eleanor always said you'd come back. She said you were the only one stubborn enough to finish it."

"Finish what?"

Maggie looked at the fire. "Your grandfather was a good man, Emma. The best man on this island. And good men make enemies when they won't look the other way."

"She said he was murdered."

The word landed like a stone in still water. Maggie's hand tightened on her teacup.

"I think," Maggie said carefully, "that you should look at Ellen's paintings. Really look at them. She spent forty years trying to tell someone what she couldn't say out loud."

"Do you know who killed him?"

Maggie met her eyes. Held them. Then looked away.

"Have more tea, dear," she said. "It's going to be a long evening."
