---
type: scene
title: "The Last Good Summer"
act: 2
chapter: 8
sequence: 9
status: outlined
pov: "Eleanor Hartwell"
location: "The Harbor"
characters:
  - Eleanor Hartwell
  - Thomas Hartwell
  - Maggie Shaw
intensity: 4
timeline_mode: flashback
tags:
  - backstory
  - romance
  - family
  - nostalgia
wordTarget: 1500
notes: "FLASHBACK to summer 1982. Thomas and Eleanor at the harbor during a village festival. Thomas confides in Maggie about the forged deeds. Eleanor paints the lighthouse. A perfect summer day — the last before everything changes."
setup_scenes: []
payoff_scenes:
  - "03-11 Maggie's Confession"
---

*Summer 1982. The harbor festival.*

[[Thomas Hartwell|Thomas]] in his Sunday best, laughing at something [[Maggie Shaw|Maggie]] said. [[Eleanor Hartwell|Eleanor]] at her easel, painting [[The Lighthouse]] in the golden afternoon light. Bunting strung between the boats. Children running along the quay.

Thomas pulls Maggie aside. His smile fades. He tells her about the forged deeds — how Algernon Blackwood has been systematically stealing coastal land from fishing families for decades. He has proof. He's going to confront Algernon tomorrow.

*"Don't," Maggie says. "Go to the police on the mainland."*

*"Blackwood owns the police," Thomas says. "I have to do this face to face."*

Eleanor watches them from behind her easel. She doesn't hear the conversation, but she sees the worry on Thomas's face. She paints it into the sky — dark clouds on the horizon, approaching the lighthouse.

That evening, Thomas takes Eleanor's hand as they walk home along the cliff path. He tells her he loves her. She tells him he worries too much.

It's the last time they walk that path together.
