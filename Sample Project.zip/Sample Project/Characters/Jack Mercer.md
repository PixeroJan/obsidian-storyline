---
type: character
name: "Jack Mercer"
role: Deuteragonist
age: 35
gender: Male
occupation: Fisherman / boat mechanic
appearance: "Broad-shouldered, weather-beaten tan, dark curly hair, calloused hands, usually in a cable-knit sweater and waterproofs"
personality: "Quiet, observant, dependable. Slow to open up but fiercely protective. Carries guilt about things he's seen but never reported."
backstory: "Third-generation fisherman on Havenrock. His father Robert saw something the night Thomas Hartwell disappeared but died before telling anyone. Jack found cryptic notes in his father's logbook and has been quietly piecing things together for years."
arc: "From silent bystander to someone who acts. Learns that loyalty to the island means standing up for the truth, not staying quiet."
motivation: "Honor his father's memory by finishing what Robert started."
strengths:
  - Knows every inch of the island
  - Physically capable
  - Trustworthy
weaknesses:
  - Avoids confrontation
  - Carries survivor's guilt
  - Distrusts outsiders (initially)
allies:
  - Emma Hartwell
  - Maggie Shaw
enemies:
  - Howard Blackwood
romantic:
  - Emma Hartwell
mentors:
  - Robert Mercer
residency: "Havenrock Island"
locations:
  - "#HavenrockIsland"
  - "#TheHarbor"
  - "#TheLighthouse"
props:
  - "#FathersLogbook"
  - "#FishingKnife"
tags:
  - mystery
  - trust
  - romance
  - local
custom:
  fear: "That speaking up will put Emma in danger"
  quirk: "Whittles driftwood when thinking"
  boat_name: "The Skylark — inherited from his father"
  favorite_spot: "#TheLighthouse cliffs at dawn"
---

# Jack Mercer

Havenrock's most trusted fisherman and the deuteragonist of *The Vanishing Tide*. Jack has lived on [[Havenrock Island]] his entire life, carrying quiet suspicions about the night [[Thomas Hartwell]] vanished. When [[Emma Hartwell]] arrives, he recognizes a kindred restlessness — and a shared enemy.

## Key Relationships
- **[[Emma Hartwell]]** — The journalist from London. Their relationship begins with mutual suspicion and evolves into trust, then romance.
- **[[Maggie Shaw]]** — A family friend who helped raise Jack after his father Robert died.
- **[[Howard Blackwood]]** — The man Jack suspects is hiding the truth about the Hartwells.
