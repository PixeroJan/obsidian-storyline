---
type: character
name: "Thomas Hartwell"
role: Supporting
age: 45
gender: Male
occupation: Fisherman / amateur historian
status: "Deceased (murdered 1982)"
appearance: "In photographs: strong jaw, kind eyes, calloused hands, always in a fisherman's cap, wedding ring never removed"
personality: "Honest, stubborn, principled. The kind of man who couldn't look the other way when he discovered Algernon Blackwood's land fraud. That integrity cost him his life."
backstory: "Thomas was a respected fisherman and amateur historian of Havenrock Island. In the summer of 1982, he discovered that Algernon Blackwood had been forging land deeds to seize coastal properties from local families. When Thomas confronted Algernon, he was murdered and his death staged as a drowning. His body was weighted down in the caves beneath the lighthouse."
arc: "Revealed posthumously. Thomas represents the ordinary person who stood up against corruption. His story is the moral center of the novel."
motivation: "Protect the islanders from Blackwood's fraud."
strengths:
  - Moral courage
  - Deep knowledge of island history
  - Respected by everyone
weaknesses:
  - Too trusting
  - Confronted Algernon alone
  - Left no backup plan
allies:
  - Eleanor Hartwell
  - Maggie Shaw
enemies:
  - Howard Blackwood
residency: "Grandmother's Cottage, Havenrock Island"
locations:
  - "#HavenrockIsland"
  - "#TheHarbor"
  - "#TheLighthouse"
props:
  - "#ThomasRing"
  - "#ForgedDeeds"
  - "#FishingKnife"
tags:
  - deceased
  - mystery
  - victim
  - family-secrets
custom:
  cause_of_death: "Murdered by Algernon Blackwood — staged as drowning"
  last_seen: "The Harbor, evening of August 14, 1982"
  discovery: "His wedding ring washes up inside a bottle — the event that prompted Eleanor's letter"
  legacy: "Emma's story about him becomes a tribute, not an expose"
---

# Thomas Hartwell

The mystery at the center of *The Vanishing Tide*. Thomas was [[Emma Hartwell]]'s grandfather — a fisherman and amateur historian on [[Havenrock Island]] who was murdered by Algernon Blackwood in 1982 after discovering a land fraud scheme. His death was staged as a drowning, and the truth was buried for over forty years.

## Key Relationships
- **[[Eleanor Hartwell]]** — His wife. She discovered the truth but was silenced by threats.
- **[[Emma Hartwell]]** — His granddaughter, who finally uncovers what happened.
- **[[Maggie Shaw]]** — Close friend who saw him alive on the night he died.
- **[[Howard Blackwood]]** — Grandson of his killer, Algernon Blackwood.
