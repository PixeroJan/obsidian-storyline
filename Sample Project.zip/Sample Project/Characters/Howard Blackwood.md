---
type: character
name: "Howard Blackwood"
role: Antagonist
age: 58
gender: Male
occupation: Island commissioner / landowner
appearance: "Silver-haired, immaculately dressed even in a coastal village, sharp blue eyes, imposing posture, gold signet ring"
personality: "Charming in public, ruthless in private. Controls through influence rather than force. Believes the island's future — and his family's legacy — depends on keeping the past buried."
backstory: "Grandson of Algernon Blackwood, who murdered Thomas Hartwell over a land fraud scheme in 1982. Howard inherited both the estate and the secret. He's spent decades positioning himself as the island's benefactor while quietly buying up coastal properties for a luxury resort development."
arc: "From untouchable power broker to exposed fraud. His carefully constructed world crumbles as Emma uncovers the truth."
motivation: "Protect the Blackwood name and complete the resort deal."
strengths:
  - Political connections
  - Wealth and influence
  - Expert manipulator
weaknesses:
  - Arrogance
  - Underestimates Emma
  - Haunted by guilt he won't admit
allies:
  - Diane Blackwood
enemies:
  - Emma Hartwell
  - Jack Mercer
residency: "Blackwood Manor, Havenrock Island"
locations:
  - "#HavenrockIsland"
  - "#BlackwoodManor"
  - "#TheAnchorTavern"
props:
  - "#SignetRing"
  - "#AlgernonsJournal"
  - "#ResortPlans"
tags:
  - antagonist
  - politics
  - corruption
  - power
custom:
  fear: "Being seen as his grandfather was — a murderer"
  quirk: "Adjusts his signet ring when lying"
  vehicle: "Black Range Rover — only modern car on the island"
  wine: "Single malt Scotch, never wine"
---

# Howard Blackwood

The primary antagonist of *The Vanishing Tide*. Howard is the island commissioner of [[Havenrock Island]] and the grandson of Algernon Blackwood, who murdered [[Thomas Hartwell]] in 1982. He maintains his family's stranglehold on the island through charm, money, and barely veiled threats.

## Key Relationships
- **[[Emma Hartwell]]** — The journalist threatening to expose everything. He tries charm first, then intimidation.
- **[[Jack Mercer]]** — A local nuisance who asks too many questions about the harbor records.
- **Diane Blackwood** — His wife, who suspects more than she lets on.
- **Algernon Blackwood** — His deceased grandfather, whose sins Howard continues to cover up.
