---
type: character
name: "Maggie Shaw"
role: Supporting
age: 72
gender: Female
occupation: Retired schoolteacher
appearance: "Small, wiry, silver hair in a bun, reading glasses on a chain, always in a hand-knit cardigan, surprisingly strong grip"
personality: "Warm but evasive. Sharp memory she deploys selectively. Carries the weight of complicit silence — she knew more than she told and has lived with that guilt for decades."
backstory: "Best friend of Eleanor Hartwell since childhood. She was the last person to see Thomas alive, though she's never told anyone. A beloved schoolteacher who taught three generations of island children, including Jack Mercer."
arc: "From keeper of secrets to truth-teller. Her confession in Act 3 is the emotional climax of the story."
motivation: "Protect Eleanor's memory, but ultimately honor the truth."
strengths:
  - Knows everyone's secrets
  - Trusted by the whole island
  - Fierce when cornered
weaknesses:
  - Guilt over her silence
  - Protective to a fault
  - Health is failing
allies:
  - Emma Hartwell
  - Jack Mercer
enemies:
  - Howard Blackwood
mentors:
  - Eleanor Hartwell
residency: "Havenrock Island"
locations:
  - "#HavenrockIsland"
  - "#TheAnchorTavern"
  - "#GrandmothersCottage"
props:
  - "#TeaSet"
  - "#OldPhotographs"
tags:
  - supporting
  - secrets
  - guilt
  - witness
custom:
  fear: "Dying before she can set things right"
  quirk: "Offers tea before answering any question"
  garden: "Prize-winning roses — the only thing she can fully control"
  memory: "The sound of Thomas's boat engine the night he left"
---

# Maggie Shaw

The emotional heart of *The Vanishing Tide*. Maggie is a retired schoolteacher on [[Havenrock Island]] who was [[Eleanor Hartwell]]'s closest friend. She holds the final piece of the puzzle — she saw [[Thomas Hartwell]] alive on the night he supposedly drowned, and she has kept that secret for over forty years.

## Key Relationships
- **[[Emma Hartwell]]** — Eleanor's granddaughter. Maggie wants to protect her but knows Emma deserves the truth.
- **[[Jack Mercer]]** — A former student. Maggie helped raise him after his father died.
- **[[Howard Blackwood]]** — Despises him quietly. Knows what his family did.
- **[[Eleanor Hartwell]]** — Her lifelong friend, now deceased. Their shared secret bound them together.
