---
type: character
name: "Emma Hartwell"
role: Protagonist
age: 32
gender: Female
occupation: Investigative journalist
appearance: "Tall, auburn hair often tied back, green eyes, freckles across the nose, usually in a worn leather jacket and boots"
personality: "Tenacious, empathetic, restless. Hides vulnerability behind dry humor. Struggles with trust but deeply loyal once committed."
backstory: "Grew up spending summers on Havenrock Island with her grandparents. Left for London at 18 and never looked back — until now. A rising journalist at The Herald, she's used to chasing other people's stories but has never investigated her own family's secrets."
arc: "From detached outsider to someone who belongs. Learns that truth isn't always about exposure — sometimes it's about healing."
motivation: "Find out what really happened to her grandfather Thomas."
strengths:
  - Sharp instincts
  - Skilled interviewer
  - Refuses to give up
weaknesses:
  - Emotionally guarded
  - Tendency to push people away
  - Impatient with small-town politics
allies:
  - Jack Mercer
  - Maggie Shaw
enemies:
  - Howard Blackwood
romantic:
  - Jack Mercer
mentors:
  - Eleanor Hartwell
residency: "London (originally Havenrock Island)"
locations:
  - "#HavenrockIsland"
  - "#GrandmothersCottage"
  - "#TheLighthouse"
props:
  - "#EleanorsLetter"
  - "#ThomasRing"
  - "#OldCamera"
tags:
  - mystery
  - homecoming
  - family-secrets
  - journalist
custom:
  fear: "That the truth will destroy what little family memory she has left"
  quirk: "Talks to herself when thinking through a problem"
  theme_song: "The Chain — Fleetwood Mac"
  drink: "Black coffee, always"
  notebook: "#MoleskineNotebook — carries it everywhere"
---

# Emma Hartwell

The protagonist of *The Vanishing Tide*. Emma is an investigative journalist who returns to [[Havenrock Island]] after her grandmother [[Eleanor Hartwell]]'s death. When she discovers [[Eleanor's Letter]], she realizes her grandfather [[Thomas Hartwell]] didn't drown in 1982 — he was murdered by Algernon Blackwood over a land fraud scheme.

## Key Relationships
- **[[Jack Mercer]]** — Local fisherman. Initially suspicious of each other, they develop trust and eventually a romantic connection.
- **[[Maggie Shaw]]** — Retired schoolteacher who knew the family. Holds crucial information.
- **[[Howard Blackwood]]** — The island's corrupt commissioner. Grandson of Algernon, he's continuing the family's grip on power.
- **[[Eleanor Hartwell]]** — Her late grandmother, who kept the truth hidden for forty years.
