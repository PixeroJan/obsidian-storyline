---
type: character
name: "Eleanor Hartwell"
role: Mentor
age: 78
gender: Female
occupation: Former painter / island historian
status: Deceased
appearance: "In photographs: kind face, silver-white hair, paint-stained fingers, always wearing Thomas's wedding ring on a chain around her neck"
personality: "Warm, artistic, quietly courageous. Spent her life protecting her family while carrying an unbearable secret."
backstory: "Eleanor discovered the truth about Thomas's murder shortly after it happened but was threatened by Algernon Blackwood into silence. She spent decades painting the lighthouse and the harbor — her canvases contain hidden clues she hoped someone would eventually decode. She wrote the letter that sets the story in motion."
arc: "Revealed through flashbacks and artifacts. Her arc is one of silent resistance — she couldn't speak the truth aloud, so she embedded it in her art."
motivation: "Ensure the truth survives her."
strengths:
  - Artistic brilliance
  - Patient strategic thinking
  - Deep love for family
weaknesses:
  - Fear of Blackwood family
  - Carried guilt for her silence
  - Isolation from keeping the secret
allies:
  - Maggie Shaw
enemies:
  - Howard Blackwood
residency: "Grandmother's Cottage, Havenrock Island"
locations:
  - "#HavenrockIsland"
  - "#GrandmothersCottage"
  - "#TheLighthouse"
props:
  - "#EleanorsLetter"
  - "#LighthousePainting"
  - "#ThomasRing"
  - "#PaintBox"
tags:
  - mentor
  - deceased
  - artist
  - family-secrets
custom:
  cause_of_death: "Heart failure — the island doctor said she simply stopped fighting"
  final_words: "Spoken to Maggie: 'The paintings will explain everything'"
  signature_color: "Cobalt blue — present in every one of her paintings"
  studio: "#GrandmothersCottage attic — untouched since her death"
---

# Eleanor Hartwell

The catalyst of *The Vanishing Tide*. Eleanor was [[Emma Hartwell]]'s grandmother — a painter, island historian, and the keeper of Havenrock's darkest secret. Though deceased at the start of the story, her presence permeates every scene through her paintings, her letter, and the memories of those who loved her.

## Key Relationships
- **[[Emma Hartwell]]** — Her granddaughter. Eleanor's letter is what brings Emma back to [[Havenrock Island]].
- **[[Maggie Shaw]]** — Her lifelong confidante and the only other person who knew the truth.
- **[[Thomas Hartwell]]** — Her husband, murdered in 1982. She wore his ring until the day she died.
- **[[Howard Blackwood]]** — Grandson of her husband's killer. She feared him but outlasted him in spirit.
