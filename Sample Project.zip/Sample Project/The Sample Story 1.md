”The Vanishing Tide” is created from scratch as a sample project for the plugin. 

It’s a coastal mystery/drama set on Havenrock Island, a fictional small island off the coast of Cornwall, England.

**Premise:** Journalist Emma Hartwell returns to the island after her grandmother Eleanor dies. Hidden inside a paint box, she finds a letter revealing that her grandfather Thomas didn’t drown in 1982 as everyone believed. He was murdered by a man named Algernon Blackwood over a land fraud scheme.

**The characters:**

- **Emma Hartwell**  Protagonist. London journalist, tenacious but emotionally guarded.
- **Jack Mercer**  Local fisherman whose father also knew something. Becomes Emma’s ally and love interest.
- **Howard Blackwood**  Antagonist. Algernon’s grandson, now the island commissioner, covering up the family’s crimes while pushing a resort development deal.
- **Maggie Shaw**  Retired schoolteacher who was the last person to see Thomas alive. Has carried that secret for 40 years.
- **Eleanor Hartwell**  Deceased grandmother. A painter who hid clues in her lighthouse paintings for decades.
- **Thomas Hartwell**  The murdered grandfather. The mystery at the heart of the story.

**Structure:** 3 acts, 12 scenes across 9 chapters. Emma arrives, finds the letter, decodes Eleanor’s paintings, gets threatened by Howard, breaks into Blackwood Manor, and ultimately exposes the truth. There’s a flashback scene to the summer of 1982, and the emotional climax is Maggie’s confession. She could have stopped Thomas that night but didn’t.

It ends with Emma choosing to stay on the island, writing Thomas’s story as a tribute rather than an exposé.

I designed it to showcase every StoryLine feature: multiple scene statuses, cross-referenced setup/payoff scenes, character relationships (ally, enemy, romantic, mentor), locations with hierarchy, tags, props, custom fields, a flashback timeline mode, and a populated plot grid.