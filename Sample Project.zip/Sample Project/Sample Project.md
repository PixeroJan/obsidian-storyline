---
type: storyline
title: "The Vanishing Tide"
author: "Sample Author"
genre: Mystery / Drama
acts: 3
chapters: 9
actLabels:
  - "Act 1 — Arrival"
  - "Act 2 — Investigation"
  - "Act 3 — Reckoning"
chapterLabels:
  - "Ch 1 — The Crossing"
  - "Ch 2 — The Letter"
  - "Ch 3 — Old Friends"
  - "Ch 4 — Hidden Paintings"
  - "Ch 5 — Threats"
  - "Ch 6 — Secrets"
  - "Ch 7 — The Storm"
  - "Ch 8 — Trespassers"
  - "Ch 9 — Resolution"
filterPresets:
  - name: "Act 1 only"
    filters:
      act: 1
  - name: "Key scenes"
    filters:
      status: written
  - name: "Emma POV"
    filters:
      pov: "Emma Hartwell"
---

# The Vanishing Tide

A coastal mystery set on Havenrock Island, off the Cornish coast. When journalist Emma Hartwell returns to the island after her grandmother Eleanor's death, she uncovers a letter that reveals her grandfather Thomas didn't drown in 1982 — he was murdered. As Emma digs into the past, she must confront a powerful family, navigate old alliances, and face the truth that the island has kept buried for over forty years.
